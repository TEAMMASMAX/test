# ![logo](TOKEN/LINE.png) LINE Python

 [![Supported python versions: 3.x](https://img.shields.io/badge/python-3.x-green.svg "Supported python versions: 3.x")](https://www.python.org/downloads/) 

*Fork From* [here](https://github.com/edoi777/BotLgToken)

----

## Usage
```
Don't forget to put token desktopwin in token.json
And your mid in creator =["your mid here"]
```

## Update 03/01/2019
```
* Debug 
* Improve Logic
* Add IOSIPAD,CHROMEOS Token
```

## Fix and upload by 
[@author](https://line.me/ti/p/3eamxoks_T)
